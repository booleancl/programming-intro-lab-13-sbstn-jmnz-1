\c bigcities

SELECT name, population/area AS density FROM cities ORDER BY density DESC;