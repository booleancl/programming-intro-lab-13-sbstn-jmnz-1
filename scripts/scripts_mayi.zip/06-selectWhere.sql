-- Seleccionar todo desde la tabla ciudades donde el pais sea IGUAL a India
\c bigcities

SELECT * FROM cities WHERE country = 'India';