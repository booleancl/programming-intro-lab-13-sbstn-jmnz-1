\c bigcities

SELECT SUM(population) FROM cities;