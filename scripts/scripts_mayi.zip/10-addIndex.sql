\c bigcities

CREATE INDEX name_idx on cities(name);