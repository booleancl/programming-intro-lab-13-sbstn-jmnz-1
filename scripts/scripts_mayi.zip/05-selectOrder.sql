\c bigcities

SELECT name, country, population FROM cities ORDER BY population DESC LIMIT 5;