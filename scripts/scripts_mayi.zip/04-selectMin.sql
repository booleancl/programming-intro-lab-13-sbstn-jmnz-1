\c bigcities

SELECT MIN(population) FROM cities;