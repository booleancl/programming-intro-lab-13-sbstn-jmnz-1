\c bigcities

SELECT COUNT(name) FROM cities;
