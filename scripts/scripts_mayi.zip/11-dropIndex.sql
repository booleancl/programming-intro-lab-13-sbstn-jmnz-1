\c bigcities

DROP INDEX name_idx;